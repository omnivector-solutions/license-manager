"""license_manager"""


VERSION = "0.5.4-dev0"
