"""license-manager agent module."""
