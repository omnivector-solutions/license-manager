#!/usr/bin/env python3
"""license_manager.lic_tools"""
from .lic_handler import LicHandler  # NOQA
