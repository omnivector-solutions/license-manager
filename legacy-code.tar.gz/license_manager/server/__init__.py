"""license_manager.server"""
